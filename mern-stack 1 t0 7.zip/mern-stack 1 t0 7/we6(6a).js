// script.js
function greetExternal() {
  alert("Hello from External JavaScript!");
}
